*******************
``matplotlib.text``
*******************

.. automodule:: matplotlib.text
   :no-members:

.. autoclass:: matplotlib.text.Text
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: matplotlib.text.Annotation
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: matplotlib.text.OffsetFrom
   :members:
   :undoc-members:
   :show-inheritance:
