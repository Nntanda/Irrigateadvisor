************************
``matplotlib.docstring``
************************

.. automodule:: matplotlib.docstring
   :members:
   :undoc-members:
   :show-inheritance:
