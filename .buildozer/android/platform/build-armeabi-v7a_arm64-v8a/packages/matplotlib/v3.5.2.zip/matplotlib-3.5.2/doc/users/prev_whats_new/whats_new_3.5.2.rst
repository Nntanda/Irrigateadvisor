Windows on ARM support
----------------------

Preliminary support for Windows on arm64 target has been added; this requires
FreeType 2.11 or above.

No binary wheels are available yet but it may be built from source.
