:orphan:

.. raw:: html

  <meta http-equiv="refresh" content="0; url=https://matplotlib.org/mpl-third-party/">
